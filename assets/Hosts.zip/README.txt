1. copy all items in hosts.txt.
2. paste into Windows\System32\drivers\etc\hosts
**DO NOT OVERWRITE PREVIOUS TEXT**